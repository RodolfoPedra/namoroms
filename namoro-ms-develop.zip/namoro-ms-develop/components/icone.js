import React from "react";

const Icone = ({ nome }) => {
  return <span className="material-icons-round">{nome}</span>;
};

export default Icone

import React from "react";
import Site from "layout/site";

const Home = () => {
  return (
    <Site />
  );
}

export default Home

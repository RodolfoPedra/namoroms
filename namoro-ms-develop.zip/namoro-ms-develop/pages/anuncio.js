import Anuncio from "layout/site/anuncio"

const PaginaAnuncio = () => {
  return (
    <Anuncio />
  )
}

export default PaginaAnuncio
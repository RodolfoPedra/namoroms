import Login from "layout/portal/login"

const LoginPortal = () => {
  return (
    <Login />
  )
}

export default LoginPortal
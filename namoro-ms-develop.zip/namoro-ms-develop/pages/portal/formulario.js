import FormularioParaAnuncio from "layout/portal/formulario-para-anuncio"

const FormularioAnuncio = () => {
  return (
    <FormularioParaAnuncio />
  )
}

export default FormularioAnuncio
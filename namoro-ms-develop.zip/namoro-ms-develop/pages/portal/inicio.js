import Inicio from "layout/portal/inicio"

const InicioPortal = () => {
  return (
    <Inicio />
  )
}

export default InicioPortal
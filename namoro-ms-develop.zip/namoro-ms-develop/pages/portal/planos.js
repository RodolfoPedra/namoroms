import Planos from "layout/portal/planos"

const PlanosPortal = () => {
  return (
    <Planos />
  )
}

export default PlanosPortal
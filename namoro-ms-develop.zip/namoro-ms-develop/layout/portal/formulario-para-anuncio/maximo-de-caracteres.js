const maximoDeCaracteres = (value, max) => value.toString().slice(0, max);
export default maximoDeCaracteres;

import React from "react";
import Site from "./site";

const Home = () => {
  return (
    <Site />
  );
}

export default Home

module.exports = {
  reactStrictMode: true,
  webpack5: false
}
